﻿using System;

using System.Collections.Generic;

using System.Linq;
using System.Text;

namespace лаба_2

{

    class Example2 // начало описания класса

    // Example2

    {

        static void Main()

        {

            double p = ; 
            double x = ;

            double y = Math.Cos(p * x) / (1 + x * x);

            Console.WriteLine();

            Console.WriteLine(" x = {0} \t y = {1} ", x, y);
            double x = 1;
            double z1 = (x * x + 2 * x - 3 + (x + 1) * Math.Sqrt(x * x - 9)) / (x * x - 2 * x - 3 + (x - 1) * Math.Sqrt(x * x - 9));
            double z2 = Math.Sqrt((x + 3) / (x - 3));
        }
       
    }

}